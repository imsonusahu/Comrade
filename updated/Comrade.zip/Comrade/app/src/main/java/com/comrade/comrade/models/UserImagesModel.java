package com.comrade.comrade.models;

public class UserImagesModel {


    String userImages;

    public UserImagesModel() {
    }

    public String getUserImages() {
        return userImages;
    }

    public void setUserImages(String userImages) {
        this.userImages = userImages;
    }

    public UserImagesModel(String userImages) {
        this.userImages = userImages;
    }
}
