package com.comrade.comrade.models;

public class InterestModel {

    private String interestType;

    public InterestModel() {
    }

    public InterestModel(String interestType) {
        this.interestType = interestType;
    }

    public String getInterestType() {
        return interestType;
    }

    public void setInterestType(String interestType) {
        this.interestType = interestType;
    }
}
